# زد علما — iOS project

Capacitor wrapper for the existing Arabic study app.

**This is the iOS source project, not a signed IPA.** Building and signing require macOS + Xcode and Apple signing configuration.

See `README-AR.txt` for the full Arabic build and distribution steps.
