#!/bin/bash
set -e
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js 22+ is required. Install Node.js, then run this file again."
  read -r -p "Press Enter to close..."
  exit 1
fi
npm install
if [ ! -d ios ]; then
  npx cap add ios
fi
npx cap sync ios
npx cap open ios
